export interface Clasificador {
    id?: number;
    descripcion?: string;
    equivalencia?: string;
    abreviatura?: string;
}
