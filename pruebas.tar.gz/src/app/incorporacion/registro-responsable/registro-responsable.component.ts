import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-responsable',
  templateUrl: './registro-responsable.component.html',
  styleUrls: ['./registro-responsable.component.scss']
})
export class RegistroResponsableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
