export interface Mensaje {
    codigo?: number;
    descripcion?: string;
}
