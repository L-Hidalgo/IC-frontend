import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MigracionesRoutingModule } from './migraciones-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MigracionesRoutingModule
  ]
})
export class MigracionesModule { }
