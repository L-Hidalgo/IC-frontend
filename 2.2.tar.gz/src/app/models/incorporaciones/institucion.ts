export interface Institucion {
    idInstitucion: number;
    nombreInstitucion: string;
    fechaInicio?: string;
    fechaFin?: string;
  }