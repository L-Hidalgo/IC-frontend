export interface GradoAcademico {
    idGradoAcademico: number;
    nombreGradoAcademico: string;
    fechaInicio?: string;
    fechaFin?: string;
}