/* export const environment = {
  production: true
}; */


// import { DataServiceConfig } from "str-auth-lib";

/* export const keycloakConfig: DataServiceConfig = {
  url: 'https://desalogin.impuestos.gob.bo',
  realm: 'login',
  clientId: 'app-frontend'
}; */

export const environment = {
  environmentName: 'producción',
  production: true,
  baseUrl: '',
  api: '/sen-safe-launcher-rest',
  api2: '/sen-safe-launcher-rest',
  apiIcBack: 'http://localhost:8000',
};