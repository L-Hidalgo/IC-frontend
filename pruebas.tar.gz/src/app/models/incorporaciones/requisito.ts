export interface Requisito {
  idRequisito: number;
  formacionRequisito?: string;
  expCargoRequisito?: string;
  expAreaRequisito?: string;
  expMandoRequisito?: string;
  puestoId: number;
  fechaInicio?: string;
  fechaFin?: string;
}