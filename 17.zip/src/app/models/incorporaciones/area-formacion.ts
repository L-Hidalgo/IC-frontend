export interface AreaFormacion {
  idAreaFormacion: number;
  nombreAreaFormacion: string;
  fechaInicio?: string;
  fechaFin?: string;
}